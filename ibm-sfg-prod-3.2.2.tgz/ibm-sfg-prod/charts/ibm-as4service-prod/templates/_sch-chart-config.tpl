# (C) Copyright 2025 Precisely Incorporated. All rights reserved.

{{- /*
Chart specific config file for SCH (Shared Configurable Helpers)

_sch-chart-config.tpl is a config file for the chart to specify additional 
values and/or override values defined in the sch/_config.tpl file.
 
*/ -}}

{{- /*
"sch.chart.config.values" contains the chart specific values used to override or provide
additional configuration values used by the Shared Configurable Helpers.
*/ -}}
{{- define "as4.sch.chart.config.values" -}}
sch:
  chart:
    appName: "as4"
    components:
      appInstance:
        name: "as4-1"
      catalogServer:
        name: "catalog-server"
      containerServer:
        name: "container-server"
      informationalServer:
        name: "informational-server"
      operationalServer:
        name: "operational-server"
      operationalBackendService:
        name: "operational-backend-service"
      catalogAutoscaler:
        name: "catalog-autoscaler"
      containerAutoscaler:
        name: "container-autoscaler"
      informationalAutoscaler:
        name: "informational-autoscaler"
      operationalAutoscaler:
        name: "operational-autoscaler"
      catalogInternalRoute:
        name: "catalog-internal-route"
      catalogExternalRoute:
        name: "catalog-external-route"
      containerInternalRoute:
        name: "container-internal-route"
      containerExternalRoute:
        name: "container-external-route"
      operationalInternalRoute:
        name: "operational-internal-route"
      operationalExternalRoute:
        name: "operational-external-route"
      informationalInternalRoute:
        name: "informational-internal-route"
      informationalExternalRoute:
        name: "informational-external-route"
      dbSetup:
        name: as4-db-setup
      dmConfigmap:
        name: "dm-config"
      documentService:
        name: "document-service"
      dmAppInstance:
        name: "document"
      serverSecret:
        name: "as4-secret"
      headlessService:
        name: "as4-svc"
      configmap:
        name: "app-config"
      dashboard:
        name: "grafana"
      defaultNetworkPolicy:
        name: "default-network-policy"
      appResourcesPVC:
        name: "resources"
      appLogsPVC:
        name: "logs"
      appDocumentsPVC:
        name: "documents"
      tlsSetupJob:
        name: "preinstall-tls-setup-job"
      patchIngressJob:
        name: "postinstall-patch-ingress-job"
      cleanupJob:
        name: "post-delete-cleanup-job"
      networkPolicies:
        ingressDenyAll: 
          name: "np-ingress-deny-all" 
        ingressAllowNs: 
          name: "np-ingress-allow-ns"
        ingressAllowExt:
          name: "np-ingress-allow-ext"
        egressDenyAll:
          name: "np-egress-deny-all"
        egressAllowNs:
          name: "np-egress-allow-ns"
      ibmDefaultPullSecret:
        name: "ibm-entitlement-key"
    labelType: "prefixed"
    podSecurityContextTest:
      runAsNonRoot: true
      {{- if ge (.Capabilities.KubeVersion.Minor|int) 24 }}
      seccompProfile:
        type: RuntimeDefault
      {{- end }}
      supplementalGroups: {{ .Values.security.supplementalGroups }}
          {{- if .Values.security.fsGroup }}
      fsGroup: {{ .Values.security.fsGroup }}
          {{- end }}
          {{- if .Values.security.fsGroupChangePolicy }}
      fsGroupChangePolicy: {{ .Values.security.fsGroupChangePolicy }}
          {{- end }}
    
    metering:
      {{- if eq (toString .Values.licenseType | lower) "non-prod"  }}
      productID: {{ template "as4.metering.nonProductId" . }}
      productName: {{ template "as4.metering.nonProductName" . }}
      {{- else }}
      productID: {{ template "as4.metering.productId" . }}
      productName: {{ template "as4.metering.productName" . }}
      {{- end }}
      productVersion: {{ template "as4.metering.productVersion" . }}
      productMetric: {{ template "as4.metering.productMetric" . }}
    nonMetering:
      nonChargeableProductMetric: "FREE"
    podSecurityContext:
      runAsNonRoot: true
      {{- if ge (.Capabilities.KubeVersion.Minor|int) 24 }}
      seccompProfile:
        type: RuntimeDefault
      {{- end }}
      supplementalGroups: {{ .Values.security.supplementalGroups }}
	  {{- if .Values.security.fsGroup }}
      fsGroup: {{ .Values.security.fsGroup }}
	  {{- end }}
	  {{- if .Values.security.runAsUser }}
      runAsUser: {{ .Values.security.runAsUser }}
	  {{- end }}
	  {{- if .Values.security.runAsGroup }}
      runAsGroup: {{ .Values.security.runAsGroup }}
	  {{- end }}
    containerSecurityContext:
        privileged: false
          {{- if .Values.security.runAsUser }}
        runAsUser: {{ .Values.security.runAsUser }}
	    {{- end }}
	    {{- if .Values.security.runAsGroup }}
        runAsGroup: {{ .Values.security.runAsGroup }}
  	  {{- end }}
        readOnlyRootFilesystem: false
        allowPrivilegeEscalation: false
        capabilities:
          drop:
          - ALL
    nodeAffinity:
      nodeAffinityRequiredDuringScheduling:
        operator: In
        values:
        - amd64
        - ppc64le
      nodeAffinityPreferredDuringScheduling:
        amd64:
          weight: 3
          operator: In
          key: beta.kubernetes.io/arch
    spec:
      serviceAccountName: my-service-account
      podSecurityContext:
        runAsNonRoot: true
        supplementalGroups: {{ .Values.security.supplementalGroups }}
    	  {{- if .Values.security.fsGroup }}
        fsGroup: {{ .Values.security.fsGroup }}
	  {{- end }}
	  {{- if .Values.security.runAsUser }}
        runAsUser: {{ .Values.security.runAsUser }}
  	  {{- end }}
  	  {{- if .Values.security.runAsGroup }}
        runAsGroup: {{ .Values.security.runAsGroup }}
	  {{- end }}
      containerSecurityContext:
        privileged: false
          {{- if .Values.security.runAsUser }}
        runAsUser: {{ .Values.security.runAsUser }}
	    {{- end }}
	    {{- if .Values.security.runAsGroup }}
        runAsGroup: {{ .Values.security.runAsGroup }}
  	  {{- end }}
        readOnlyRootFilesystem: false
        allowPrivilegeEscalation: false
        capabilities:
          drop:
          - ALL
    specSecurityContext:
      hostNetwork: false
      hostPID: false
      hostIPC: false
    helmTestPodSecurityContext:
      securityContext:
        privileged: false
        readOnlyRootFilesystem: false
        allowPrivilegeEscalation: false
        capabilities:
          drop:
          - ALL
{{- end -}}
